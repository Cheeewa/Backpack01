package com.company;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {
        // write your code here
        try (FileInputStream inputStream = new FileInputStream(args[0]);
             Scanner sc = new Scanner(inputStream, StandardCharsets.UTF_8)) {

            //read file here
            String[] nk = sc.nextLine().split(" ");
            int n = Integer.parseInt(nk[0]);
            int k = Integer.parseInt(nk[1]);
            ArrayList<String> lines = new ArrayList<>();
            ArrayList<Integer> c = new ArrayList<>();
            ArrayList<Integer> a = new ArrayList<>();
            //read all values of c and a into String array and sort them by the proportion
            while (sc.hasNextLine()){
                lines.add(sc.nextLine());
            }
            //sortiere nach gewicht
            qSort(lines, 0, lines.size()-1);
            //i
            double[][] wt = new double[lines.size()][lines.size()];

            for (int i = 0; i < lines.size(); i++){
                for (int j = 0; j < lines.size(); j++){

                }
            }

            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void qSort(ArrayList<String> input, int begin, int end){
        if (begin < end){
            int partitionIndex = partition(input, begin, end);

            qSort(input, begin, partitionIndex-1);
            qSort(input, partitionIndex+1, end );
        }
    }

    private static int partition(ArrayList<String> input, int begin, int end){
        double pivot = getDouble(end, input);
        int i = (begin-1);

        for (int j = begin; j < end; j++){
            if (getDouble(j, input) < pivot){
                i++;

                String swapTemp = input.get(i);
                input.set(i, input.get(j));
                input.set(j, swapTemp);
            }
        }

        String swapTemp = input.get(i+1);
        input.set(i+1, input.get(end));
        input.set(end, swapTemp);

        return i+1;
    }

    private static double getDouble(int pos, ArrayList<String> input){
        String[] l = input.get(pos).split(" ");
        return Double.parseDouble(l[0]);
    }
}
